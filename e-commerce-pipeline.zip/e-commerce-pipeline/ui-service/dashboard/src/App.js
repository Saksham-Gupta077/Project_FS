import React, { useState } from 'react';
import './App.css';

function App() {
  const [orderId, setOrderId] = useState('');
  const [order, setOrder] = useState(null);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleFetchOrder = async () => {
    if (!orderId) {
      setError('Please enter an Order ID.');
      setOrder(null);
      return;
    }
    setIsLoading(true);
    setError('');
    setOrder(null);

    try {
      // The API backend we created is running on port 4000
      const response = await fetch(`http://localhost:4000/order/${orderId}`);
      if (!response.ok) {
        throw new Error(`Order not found or server error (Status: ${response.status})`);
      }
      const data = await response.json();
      setOrder(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="App">
      <header className="App-header">
        <h1>Order Status Dashboard</h1>
        <div className="search-container">
          <input
            type="text"
            value={orderId}
            onChange={(e) => setOrderId(e.target.value)}
            placeholder="Enter Order ID"
          />
          <button onClick={handleFetchOrder} disabled={isLoading}>
            {isLoading ? 'Searching...' : 'Get Status'}
          </button>
        </div>
        
        {error && <p className="error">{error}</p>}

        {order && (
          <div className="order-details">
            <h2>Order Details</h2>
            <p><strong>Order ID:</strong> {order.orderId}</p>
            <p><strong>Customer ID:</strong> {order.customerId}</p>
            <p className={`status status-${order.status}`}>{order.status}</p>
            {order.failureReason && <p><strong>Reason:</strong> {order.failureReason}</p>}
             <p><strong>Created At:</strong> {new Date(order.createdAt).toLocaleString()}</p>
            <h3>Items</h3>
            <ul>
              {order.items.map((item, index) => (
                <li key={index}>
                  {item.quantity} x {item.productId} @ ${item.price}
                </li>
              ))}
            </ul>
          </div>
        )}
      </header>
    </div>
  );
}

export default App;